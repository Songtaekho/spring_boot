package com.coding404.myweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMyWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMyWebApplication.class, args);
	}

}
