package com.coding404.myweb.product.service;

import com.coding404.myweb.command.ProductVO;

import java.util.ArrayList;

public interface ProductService {

    int productRegist(ProductVO vo);
    ArrayList<ProductVO> getList(String prodWriter);
    ProductVO getDetail(String prodId);
    void productUpdate(ProductVO vo);

}
