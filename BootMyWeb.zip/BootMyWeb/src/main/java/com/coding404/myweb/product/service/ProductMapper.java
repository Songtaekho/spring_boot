package com.coding404.myweb.product.service;

import com.coding404.myweb.command.ProductVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;

@Mapper
public interface ProductMapper {

    int productRegist(ProductVO vo);
    ArrayList<ProductVO> getList(String prodWriter);
    ProductVO getDetail(String prodId);
    void productUpdate(ProductVO vo);
}
